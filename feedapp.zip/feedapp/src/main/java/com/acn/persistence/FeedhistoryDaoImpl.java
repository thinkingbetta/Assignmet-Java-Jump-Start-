package com.acn.persistence;

import com.acn.model.Feedhistory;
import com.acn.repository.FeedhistoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class FeedhistoryDaoImpl implements FeedhistoryDao {
    @Autowired
    FeedhistoryRepository feedhistoryRepository;
    @Override
    public void saveNewFeedhistory(Feedhistory feedhistory) {
        feedhistoryRepository.save(feedhistory);
    }
}
