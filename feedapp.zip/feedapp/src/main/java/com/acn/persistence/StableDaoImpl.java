package com.acn.persistence;

import com.acn.model.Stable;
import com.acn.repository.StableRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class StableDaoImpl implements StableDao {
    @Autowired
    StableRepository stableRepository;

    @Override
    public void saveNewStable(Stable stable) {
        stableRepository.save(stable);
    }

    @Override
    public void changeStable(Stable stable) {
        stableRepository.save(stable);
    }

    @Override
    public void removeStable(Long id) {
        stableRepository.deleteById(id);
    }

    @Override
    public Stable getStableById(Long id) {
        Optional<Stable> stable = stableRepository.findById(id);
        return stable.orElse(null);
    }

    @Override
    public List<Stable> getAllStable() {
        return (List<Stable>) stableRepository.findAll();
    }
}
