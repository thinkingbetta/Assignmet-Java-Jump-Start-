package com.acn.persistence;

import com.acn.model.Owner;
import com.acn.repository.OwnerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class OwnerDaoImpl implements OwnerDao {
    @Autowired
    OwnerRepository ownerRepository;

    @Override
    public void saveNewOwner(Owner owner) {
        ownerRepository.save(owner);
    }

    @Override
    public void changeOwner(Owner owner) {
        ownerRepository.save(owner);
    }
    @Override
    public void removeOwner(Long id) {
        ownerRepository.deleteById(id);
    }

    @Override
    public Owner getOwnerById(Long id) {
        Optional<Owner> owner= ownerRepository.findById(id);
        return owner.orElse(null);
    }

    @Override
    public List<Owner> getAllOwner() {
        return (List<Owner>) ownerRepository.findAll();
    }

}
