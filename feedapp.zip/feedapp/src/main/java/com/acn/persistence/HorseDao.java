package com.acn.persistence;

import com.acn.model.Horse;

import java.time.LocalDateTime;
import java.util.List;

public interface HorseDao {
    void saveNewHorse(Horse horse);
    void changeHorse(Horse horse);
    Horse getHorseById(Long id);
    List<Horse> getAllHorse();
    void feed(Integer countfeedtimes, LocalDateTime lasttimefed, Long id);
    void changeHorseName(String name, Long id);
    void changeHorseNickname(String nickname, Long id);
    void changeHorseBreed(String breed, Long id);
    void changeHorseMaxFeedtimes(Integer maxfeedtimes, Long id);
    void changeHorseMinutesInterval(Integer minutesinterval, Long id);
    void changeOwner(Long ownerid,Long id);
    void moveToOtherStable(Long stableid, Long id);
    void removeHorse(Long id);


}
