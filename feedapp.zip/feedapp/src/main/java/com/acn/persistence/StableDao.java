package com.acn.persistence;

import com.acn.model.Stable;

import java.util.List;

public interface StableDao {

    void saveNewStable(Stable stable);
    void changeStable(Stable stable);
    void removeStable(Long id);
    Stable getStableById(Long id);
    List<Stable> getAllStable();

}
