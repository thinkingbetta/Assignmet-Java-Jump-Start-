package com.acn.persistence;

import com.acn.model.Feedhistory;

public interface FeedhistoryDao {
    void saveNewFeedhistory(Feedhistory feedhistory);
}
