package com.acn.persistence;

import com.acn.model.Owner;


import java.util.List;

public interface OwnerDao {
    void saveNewOwner(Owner owner);
    void changeOwner(Owner owner);
    void removeOwner(Long id);
    Owner getOwnerById(Long id);
    List<Owner> getAllOwner();
}
