package com.acn.persistence;

import com.acn.model.Horse;
import com.acn.repository.HorseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
@Component
public class HorseDaoImpl implements HorseDao {
    @Autowired
    HorseRepository horseRepository;
    @Override
    public void saveNewHorse(Horse horse) {
        horseRepository.save(horse);
    }

    @Override
    public void changeHorse(Horse horse) {
        horseRepository.save(horse);
    }

    @Override
    public Horse getHorseById(Long id) {
        Optional<Horse> horse = horseRepository.findById(id);
        return horse.orElse(null);
    }

    @Override
    public List<Horse> getAllHorse() {
        return (List<Horse>) horseRepository.findAll();
    }

    @Override
    public void feed(Integer countfeedtimes, LocalDateTime lasttimefed, Long id) {
        horseRepository.feed(countfeedtimes, lasttimefed, id);
    }

    @Override
    public void changeHorseName(String name, Long id) {
        horseRepository.changeHorseName(name,id);
    }

    @Override
    public void changeHorseNickname(String nickname, Long id) {
        horseRepository.changeHorseNickname(nickname, id);
    }

    @Override
    public void changeHorseBreed(String breed, Long id) {
        horseRepository.changeHorseBreed(breed, id);
    }

    @Override
    public void changeHorseMaxFeedtimes(Integer maxfeedtimes, Long id) {
        horseRepository.changeHorseMaxFeedtimes(maxfeedtimes, id);
    }

    @Override
    public void changeHorseMinutesInterval(Integer minutesinterval, Long id) {
        horseRepository.changeHorseMinutesInterval(minutesinterval, id);
    }

    @Override
    public void changeOwner(Long ownerid, Long id) {
        horseRepository.changeOwner(ownerid, id);
    }

    @Override
    public void moveToOtherStable(Long stableid, Long id) {
        horseRepository.moveToOtherStable(stableid, id);
    }

    @Override
    public void removeHorse(Long id) {
        horseRepository.deleteById(id);

    }
}


