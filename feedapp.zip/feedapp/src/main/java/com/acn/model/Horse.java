package com.acn.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.MappedCollection;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


public class Horse {

    @Id
    private Long id;
    private String name;
    private String nickname;
    private String breed;
    private Integer maxfeedtimes = 4;
    private Integer minutesinterval = 120;
    private Integer countfeedtimes = 0;
    private LocalDateTime lasttimefed = LocalDateTime.of( 1970,01,01,00,00,01);
    @MappedCollection(keyColumn = "id", idColumn = "horseid")
    private List<Feedhistory> feedhistoryList = new ArrayList<>();

    public Horse() {
    }

    public Horse(String name, String nickname, String breed, Integer maxfeedtimes, Integer minutesinterval) {
        this.name = name;
        this.nickname = nickname;
        this.breed = breed;
        this.maxfeedtimes = maxfeedtimes;
        this.minutesinterval = minutesinterval;
    }

    public Horse(Long id, String name, String nickname, String breed, Integer maxfeedtimes, Integer countfeedtimes) {
        this.id = id;
        this.name = name;
        this.nickname = nickname;
        this.breed = breed;
        this.maxfeedtimes = maxfeedtimes;
        this.countfeedtimes = countfeedtimes;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public Integer getMaxfeedtimes() {
        return maxfeedtimes;
    }

    public void setMaxfeedtimes(Integer maxfeedtimes) {
        this.maxfeedtimes = maxfeedtimes;
    }

    public Integer getMinutesinterval() {
        return minutesinterval;
    }

    public void setMinutesinterval(Integer minutesinterval) {
        this.minutesinterval = minutesinterval;
    }

    public Integer getCountfeedtimes() {
        return countfeedtimes;
    }

    public void setCountfeedtimes(Integer countfeedtimes) {
        this.countfeedtimes = countfeedtimes;
    }

    public LocalDateTime getLasttimefed() {
        return lasttimefed;
    }

    public void setLasttimefed(LocalDateTime lasttimefed) {
        this.lasttimefed = lasttimefed;
    }

    public List<Feedhistory> getFeedhistoryList() {
        return feedhistoryList;
    }
    public void addFeedhistory(Feedhistory feedhistory){feedhistoryList.add(feedhistory);}

    public void setFeedhistoryList(List<Feedhistory> feedhistoryList) {
        this.feedhistoryList = feedhistoryList;
    }


    @Override
    public String toString() {
        return "Horse{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", nickname='" + nickname + '\'' +
                ", breed='" + breed + '\'' +
                ", maxfeedtimes=" + maxfeedtimes +
                ", minutesinterval=" + minutesinterval +
                ", countfeedtimes=" + countfeedtimes +
                ", lasttimefed=" + lasttimefed +
                '}';
    }
}
