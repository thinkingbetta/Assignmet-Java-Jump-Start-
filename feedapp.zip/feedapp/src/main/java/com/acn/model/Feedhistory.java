package com.acn.model;

import org.springframework.data.annotation.Id;

import java.time.LocalDateTime;

public class Feedhistory {

    @Id
    private Long id;
    private LocalDateTime feedingtime;
    private Long horseid;


    public Feedhistory(LocalDateTime feedingtime, Long horseid) {
        this.feedingtime = feedingtime;

        this.horseid = horseid;
    }

    public Feedhistory() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDateTime getFeedingtime() {
        return feedingtime;
    }

    public void setFeedingtime(LocalDateTime feedingtime) {
        this.feedingtime = feedingtime;
    }

    public Long getHorseid() {
        return horseid;
    }

    public void setHorseid(Long horseid) {
        this.horseid = horseid;
    }

    @Override
    public String toString() {
        return "Feedhistory{" +
                "id=" + id +
                ", feedingtime=" + feedingtime +
                '}';
    }

}
