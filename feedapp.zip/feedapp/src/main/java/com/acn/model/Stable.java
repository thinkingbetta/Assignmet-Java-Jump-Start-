package com.acn.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.MappedCollection;



import java.util.List;

public class Stable {
    @Id
    private Long id;
    private String stablename;
    @MappedCollection(keyColumn = "id", idColumn = "stableid")
    private List<Horse> horseList;

    public Stable() {
    }

    public Stable(String stablename, List<Horse> horseList) {
        this.stablename = stablename;
        this.horseList = horseList;
    }


    public Stable(String stablename) {
        this.stablename = stablename;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStablename() {
        return stablename;
    }

    public void setStablename(String stablename) {
        this.stablename = stablename;
    }

    public List<Horse> getHorseList() {
        return horseList;
    }
    public void addHorse(Horse horse){horseList.add(horse);}

    public void setHorseList(List<Horse> horseList) {
        this.horseList = horseList;
    }

    @Override
    public String toString() {
        return "Stable{" +
                "id=" + id +
                ", stablename='" + stablename + '\'' +
                ", horseList=" + horseList +
                '}';
    }
}
