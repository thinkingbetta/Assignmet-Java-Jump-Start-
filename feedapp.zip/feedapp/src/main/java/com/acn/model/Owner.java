package com.acn.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.MappedCollection;

import java.util.List;

public class Owner {
    @Id
    private Long id;
    private String ownername;
    @MappedCollection(keyColumn = "id", idColumn = "ownerid")
    private List<Horse> horseList;

    public Owner(String ownername, List<Horse> horseList) {
        this.ownername = ownername;
        this.horseList = horseList;
    }

    public Owner(String ownername) {
        this.ownername = ownername;
    }

    public Owner() {
    }

    public Owner(Long id, String ownername, List<Horse> horseList) {
        this.id = id;
        this.ownername = ownername;
        this.horseList = horseList;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOwnername() {
        return ownername;
    }

    public void setOwnername(String ownername) {
        this.ownername = ownername;
    }

    public List<Horse> getHorseList() {
        return horseList;
    }

    public void setHorseList(List<Horse> horseList) {
        this.horseList = horseList;
    }

    @Override
    public String toString() {
        return "Owner{" +
                "id=" + id +
                ", ownername='" + ownername + '\'' +
                ", horseList=" + horseList +
                '}';
    }
}
