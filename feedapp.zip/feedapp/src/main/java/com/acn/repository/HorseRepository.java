package com.acn.repository;

import com.acn.model.Horse;
import org.springframework.data.jdbc.repository.query.Modifying;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;

@Repository
public interface HorseRepository extends CrudRepository<Horse,Long> {
    @Query("UPDATE horse SET countfeedtimes = :countfeedtimes , lasttimefed = :lasttimefed  where id = :id") @Modifying
    void feed(Integer countfeedtimes, LocalDateTime lasttimefed, Long id);
    @Query("UPDATE horse SET name = :name where id = :id") @Modifying
    void changeHorseName(String name, Long id);
    @Query("UPDATE horse SET nickname = :nickname where id = :id") @Modifying
    void changeHorseNickname(String nickname, Long id);
    @Query("UPDATE horse SET breed = :breed where id = :id") @Modifying
    void changeHorseBreed(String breed, Long id);
    @Query("UPDATE horse SET maxfeedtimes = :maxfeedtimes where id = :id") @Modifying
    void changeHorseMaxFeedtimes(Integer maxfeedtimes, Long id);
    @Query("UPDATE horse SET minutesinterval = :minutesinterval where id = :id") @Modifying
    void changeHorseMinutesInterval(Integer minutesinterval, Long id);
    @Query("UPDATE horse SET  stableid = :stableid where id = :id") @Modifying
    void moveToOtherStable(Long stableid, Long id);
    @Query("UPDATE horse SET  ownerid = :ownerid where id = :id") @Modifying
    void changeOwner( Long ownerid, Long id);
}
