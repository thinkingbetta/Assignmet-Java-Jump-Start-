package com.acn.service;

import com.acn.model.Owner;

import java.util.List;

public interface OwnerService {
    void saveNewOwner(Owner owner);
    void changeOwner(Owner owner);
    void removeOwner(Long id);
    Owner getOwnerById(Long id);
    List<Owner> getAllOwner();
    Boolean giveHorseToOtherOwner(Long idowner, Long idhorse);
}
