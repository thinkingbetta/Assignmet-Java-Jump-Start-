package com.acn.service;

import com.acn.model.Stable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface StableService {
    void saveNewStable(Stable stable);
    void changeStable(Stable stable);
    void removeStable(Long id);
    Stable getStableById(Long id);
    List<Stable> getAllStable();
    Boolean moveHorseToStable(Long idstable, Long idhorse);
}
