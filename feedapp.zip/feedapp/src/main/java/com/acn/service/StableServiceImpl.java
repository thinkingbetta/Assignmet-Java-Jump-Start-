package com.acn.service;

import com.acn.model.Horse;
import com.acn.model.Stable;
import com.acn.persistence.HorseDao;
import com.acn.persistence.StableDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
public class StableServiceImpl implements StableService {
    @Autowired
    StableDao stableDao;
    @Autowired
    HorseDao horseDao;

    @Override@Transactional
    public void saveNewStable(Stable stable) {
        stableDao.saveNewStable(stable);
    }

    @Override@Transactional
    public void changeStable(Stable stable) {
        stableDao.changeStable(stable);

    }

    @Override@Transactional
    public void removeStable(Long id) {
        stableDao.removeStable(id);
    }

    @Override@Transactional
    public Stable getStableById(Long id) {
        return stableDao.getStableById(id);
    }

    @Override@Transactional
    public List<Stable> getAllStable() {
        return stableDao.getAllStable();
    }

    @Override@Transactional
    public Boolean moveHorseToStable(Long idstable, Long idhorse) {
        Horse horse = horseDao.getHorseById(idhorse);
        Stable stable = stableDao.getStableById(idstable);
        if(horse!=null && stable !=null) {
            horseDao.moveToOtherStable(idstable,idhorse);
            return true;
        } else return false;
    }

}
