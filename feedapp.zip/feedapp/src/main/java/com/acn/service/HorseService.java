package com.acn.service;

import com.acn.model.Horse;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public interface HorseService {
    void saveNewHorse(Horse horse);
    void changeHorse(Horse horse);
    void removeHorse(Long id);
    Horse getHorseById(Long id);
    List<Horse> getAllHorse();
    Boolean feed(Long id);
    void changeHorseName(String name, Long id);
    void changeHorseNickname(String nickname, Long id);
    void changeHorseBreed(String breed, Long id);
    void changeHorseMaxFeedtimes(Integer maxfeedtimes, Long id);
    void changeHorseMinutesInterval(Integer minutesinterval, Long id);
}
