package com.acn.service;

import com.acn.model.Feedhistory;
import com.acn.model.Horse;
import com.acn.persistence.FeedhistoryDao;
import com.acn.persistence.HorseDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class HorseServiceImpl implements HorseService {

    @Autowired
    HorseDao horseDao;
    @Autowired
    FeedhistoryDao feedhistoryDao;

    @Override@Transactional
    public void saveNewHorse(Horse horse) {
        horseDao.saveNewHorse(horse);
    }

    @Override@Transactional
    public void changeHorse(Horse horse) {
        horseDao.changeHorse(horse);
    }

    @Override@Transactional
    public void removeHorse(Long id) {
        horseDao.removeHorse(id);
    }

    @Override@Transactional
    public Horse getHorseById(Long id) {
        return horseDao.getHorseById(id);
    }

    @Override@Transactional
    public List<Horse> getAllHorse() {
        return horseDao.getAllHorse();
    }

    @Override@Transactional
    public Boolean feed(Long id) {
        Horse horse = horseDao.getHorseById(id);

        LocalDateTime lastTimeFed = horse.getLasttimefed();
        LocalDateTime minusInterval = LocalDateTime.now().minusMinutes(horse.getMinutesinterval());
        LocalDateTime now = LocalDateTime.now();
        LocalDate nowDate = LocalDate.from(LocalDateTime.now());
        Boolean sameDay = nowDate.equals(LocalDate.from(lastTimeFed));

        if ((lastTimeFed.isBefore(minusInterval) || lastTimeFed.isEqual(minusInterval))
                && (horse.getCountfeedtimes()<horse.getMaxfeedtimes() || !sameDay)) {
            if (sameDay) {
                horseDao.feed(horse.getCountfeedtimes() +1, now, id);
            } else {
                horseDao.feed( 1, now, id);
            }
            //Feature to implement logging of feeding events
            //feedhistoryDao.saveNewFeedhistory(new Feedhistory(now, id));
            return true;
        } else {
            return false;
        }
    }

    @Override@Transactional
    public void changeHorseName(String name, Long id) {
        horseDao.changeHorseName(name, id);
    }

    @Override@Transactional
    public void changeHorseNickname(String nickname, Long id) {
        horseDao.changeHorseNickname(nickname, id);
    }

    @Override@Transactional
    public void changeHorseBreed(String breed, Long id) {
        horseDao.changeHorseBreed(breed, id);
    }

    @Override@Transactional
    public void changeHorseMaxFeedtimes(Integer maxfeedtimes, Long id) {
        horseDao.changeHorseMaxFeedtimes(maxfeedtimes,id);
    }
    @Override@Transactional
    public void changeHorseMinutesInterval(Integer minutesinterval, Long id) {
        horseDao.changeHorseMinutesInterval(minutesinterval, id);
    }

}
