package com.acn.service;

import com.acn.model.Horse;
import com.acn.model.Owner;
import com.acn.persistence.HorseDao;
import com.acn.persistence.OwnerDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
public class OwnerServiceImpl implements OwnerService {
    @Autowired
    OwnerDao ownerDao;
    @Autowired
    HorseDao horseDao;

    @Override@Transactional
    public void saveNewOwner(Owner owner) {
        ownerDao.saveNewOwner(owner);

    }

    @Override@Transactional
    public void changeOwner(Owner owner) {
        ownerDao.changeOwner(owner);
    }

    @Override@Transactional
    public void removeOwner(Long id) {
        ownerDao.removeOwner(id);
    }

    @Override@Transactional
    public Owner getOwnerById(Long id) {
        return ownerDao.getOwnerById(id);
    }

    @Override@Transactional
    public List<Owner> getAllOwner() {
        return ownerDao.getAllOwner();
    }

    @Override@Transactional
    public Boolean giveHorseToOtherOwner(Long idowner, Long idhorse) {
        Horse horse = horseDao.getHorseById(idhorse);
        Owner owner = ownerDao.getOwnerById(idowner);
        if(horse!=null && owner !=null){
            horseDao.changeOwner(idowner,idhorse);
            return true;
        }else return false;
    }
}
