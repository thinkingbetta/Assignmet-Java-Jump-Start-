package com.acn.controller;

import com.acn.model.Owner;

import com.acn.service.OwnerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
public class OwnerRestController {
    @Autowired
    OwnerService ownerService;
    @PostMapping("/owners")
    public ResponseEntity<Owner> saveNewOwner(@RequestBody Owner owner){
        ownerService.saveNewOwner(owner);
        return ResponseEntity
                .created(URI.create("/owners/" + owner.getId()))
                .body(owner);
    }


    @PutMapping("/owners")
    public ResponseEntity<Owner> changeOwner( @RequestBody Owner owner){
        if (ownerService.getOwnerById(owner.getId()) == null){
            return ResponseEntity.notFound().build();
        }
        ownerService.changeOwner(owner);
        return ResponseEntity
                .created(URI.create("/owner/" + owner.getId()))
                .body(owner);
    }

    @DeleteMapping("/owners/{id}")
    public ResponseEntity removeOwner(@PathVariable("id") Long id) {
        if (ownerService.getOwnerById(id) == null){
            return ResponseEntity.notFound().build();
        }
        ownerService.removeOwner(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/owners/{id}")
    public ResponseEntity<Owner> getOwnerById(@PathVariable("id") Long id){
        Owner result = ownerService.getOwnerById(id);
        if(result==null){
            return  ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(result);
    }

    @GetMapping("/owners")
    public ResponseEntity<List<Owner>> getAllOwner(){
        return ResponseEntity.ok(ownerService.getAllOwner());
    }

    @PutMapping("/owners/{ownerid}/{horseid}")
    public ResponseEntity<Owner> addHorseToOwner(@PathVariable("ownerid") Long ownerId, @PathVariable("horseid") Long horseId){
        if(ownerService.giveHorseToOtherOwner(ownerId,horseId)){
            return ResponseEntity.ok(ownerService.getOwnerById(ownerId));
        } else return ResponseEntity.notFound().build();
    }
}
