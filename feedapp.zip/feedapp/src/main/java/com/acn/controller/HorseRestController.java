package com.acn.controller;

import com.acn.model.Horse;
import com.acn.service.HorseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
public class HorseRestController {
    @Autowired
    HorseService horseService;

    @PostMapping("/horses")
    public ResponseEntity<Horse> saveNewHorse(@RequestBody Horse horse){
        horseService.saveNewHorse(horse);
        return ResponseEntity
                .created(URI.create("/horses/" + horse.getId()))
                .body(horse);
    }


    @PutMapping("/horses")
    public ResponseEntity<Horse> changeHorse( @RequestBody Horse horse){
        if (horseService.getHorseById(horse.getId()) == null){
            return ResponseEntity.notFound().build();
        }
        horseService.changeHorse(horse);
        return ResponseEntity
                .created(URI.create("/horses/" + horse.getId()))
                .body(horse);
    }

    @PutMapping("/horses/{id}")
    public ResponseEntity feedHorse( @PathVariable("id") Long id){
        if (horseService.getHorseById(id) == null){
            return ResponseEntity.notFound().build();
        }
        Boolean allowedToEat = horseService.feed(id);
        if (!allowedToEat){
            return new ResponseEntity( HttpStatus.FORBIDDEN);
        }
        return  ResponseEntity.ok(horseService.getHorseById(id));
    }

    @DeleteMapping("/horses/remove/{id}")
    public ResponseEntity removeHorse(@PathVariable("id") Long id) {
        if (horseService.getHorseById(id) == null){
            return ResponseEntity.notFound().build();
        }
        horseService.removeHorse(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/horses/{id}")
    public ResponseEntity<Horse> getHorseById(@PathVariable("id") Long id){
        Horse result = horseService.getHorseById(id);
        if(result==null){
            return  ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(result);
    }

    @GetMapping("/horses")
    public ResponseEntity<List<Horse>> getAllHorse(){
        return ResponseEntity.ok(horseService.getAllHorse());
    }


    @PutMapping("/horses/changename/{name}/{id}")
    public ResponseEntity<Horse> changeHorseName( @PathVariable("name") String name,@PathVariable ("id") Long id) {
        if (horseService.getHorseById(id) == null) {
            return ResponseEntity.notFound().build();
        }
        horseService.changeHorseName(name,id);
        return ResponseEntity.ok(horseService.getHorseById(id));
    }

    @PutMapping("/horses/changenickname/{nickname}/{id}")
    public ResponseEntity<Horse> changeHorseNickame( @PathVariable("nickname") String nickname,@PathVariable ("id") Long id) {
        if (horseService.getHorseById(id) == null) {
            return ResponseEntity.notFound().build();
        }
        horseService.changeHorseNickname(nickname,id);
        return ResponseEntity.ok(horseService.getHorseById(id));
    }
    @PutMapping("/horses/changebreed/{breed}/{id}")
    public ResponseEntity<Horse> changeHorseBreed( @PathVariable("breed") String breed,@PathVariable ("id") Long id) {
        if (horseService.getHorseById(id) == null) {
            return ResponseEntity.notFound().build();
        }
        horseService.changeHorseBreed(breed,id);
        return ResponseEntity.ok(horseService.getHorseById(id));
    }
    @PutMapping("/horses/changemaxfeedtimes/{maxnum}/{id}")
    public ResponseEntity<Horse> changeHorseMaxFeedTimes( @PathVariable("maxnum") Integer maxnum,@PathVariable ("id") Long id) {
        if (horseService.getHorseById(id) == null) {
            return ResponseEntity.notFound().build();
        }
        horseService.changeHorseMaxFeedtimes(maxnum,id);
        return ResponseEntity.ok(horseService.getHorseById(id));
    }
    @PutMapping("/horses/changeinterval/{mininterval}/{id}")
    public ResponseEntity<Horse> changeHorseName( @PathVariable("mininterval") Integer mininterval,@PathVariable ("id") Long id) {
        if (horseService.getHorseById(id) == null) {
            return ResponseEntity.notFound().build();
        }
        horseService.changeHorseMinutesInterval(mininterval,id);
        return ResponseEntity.ok(horseService.getHorseById(id));
    }


}


