package com.acn.controller;

import com.acn.model.Stable;
import com.acn.service.StableService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
public class StableRestController {
    @Autowired
    private StableService stableService;

    @PostMapping("/stables")
    public ResponseEntity<Stable> saveNewStable(@RequestBody Stable stable){
        stableService.saveNewStable(stable);
        return ResponseEntity
                .created(URI.create("/stables/" + stable.getId()))
                .body(stable);
    }


    @PutMapping("/stables")
    public ResponseEntity<Stable> changeStable( @RequestBody Stable stable){
        if (stableService.getStableById(stable.getId()) == null){
            return ResponseEntity.notFound().build();
        }
        stableService.changeStable(stable);
        return ResponseEntity
                .created(URI.create("/stables/" + stable.getId()))
                .body(stable);
    }

    @DeleteMapping("/stables/{id}")
    public ResponseEntity removeStable(@PathVariable("id") Long id) {
        if (stableService.getStableById(id) == null){
            return ResponseEntity.notFound().build();
        }
        stableService.removeStable(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/stables/{id}")
    public ResponseEntity<Stable> getStableById(@PathVariable("id") Long id){
        Stable result = stableService.getStableById(id);
        if(result==null){
            return  ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(result);
    }

    @GetMapping("/stables")
    public ResponseEntity<List<Stable>> getAllStable(){
        return ResponseEntity.ok(stableService.getAllStable());
    }

    @PutMapping("/stables/{stableid}/{horseid}")
    public ResponseEntity<Stable> addHorseToStable(@PathVariable("stableid") Long stableId, @PathVariable("horseid") Long horseId){
        if(stableService.moveHorseToStable(stableId,horseId)){
            return ResponseEntity.ok(stableService.getStableById(stableId));
        } else return ResponseEntity.notFound().build();
    }
}
