package com.acn.persistence;

import com.acn.model.Owner;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class OwnerDaoImplTest {
   @Autowired
   OwnerDao ownerDao;

    @BeforeEach
    void setUp() {
        assertNotNull(ownerDao);
    }

    @Test
    void saveNewOwner() {
        Owner owner = new Owner("Jerry");
        ownerDao.saveNewOwner(owner);
        assertNotNull(owner.getId());
        System.out.println(owner);
    }

    @Test
    void changeOwner() {
        Long usedId = 2L;
        String newname = "prova";

        Owner owner = ownerDao.getOwnerById(usedId);
        owner.setOwnername(newname);
        ownerDao.changeOwner(owner);
        owner = ownerDao.getOwnerById(usedId);
        assertNotNull(owner);
        assertEquals(newname,owner.getOwnername());
        System.out.println(owner);
    }

    @Test
    void removeOwner() {
        Long usedid = 3l;
        ownerDao.removeOwner(usedid);
        assertNull(ownerDao.getOwnerById(usedid));
    }

    @Test
    void getOwnerById() {
        Long usedId = 2L;
        String newname = "prova";
        Owner owner = ownerDao.getOwnerById(usedId);
        assertNotNull(owner);
        assertEquals(newname,owner.getOwnername());
        System.out.println(owner);
    }

    @Test
    void getAllOwner() {
        List<Owner> ownerList = ownerDao.getAllOwner();
        assertTrue(ownerList.size()>0);
        ownerList.forEach(System.out::println);
    }
}