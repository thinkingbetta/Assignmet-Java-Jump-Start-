package com.acn.persistence;

import com.acn.model.Stable;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class StableDaoImplTest {
    @Autowired
    StableDao stableDao;

    @BeforeEach
    void setUp() {
        assertNotNull(stableDao);
    }

    @Test
    void saveNewStable() {
        Stable stable = new Stable("star");
        stableDao.saveNewStable(stable);
        assertNotNull(stable.getId());
        System.out.println(stable);

    }

    @Test
    void changeStable() {
        Long usedId = 2L;
        String newname = "prova";

        Stable stable = stableDao.getStableById(usedId);
        stable.setStablename(newname);
        stableDao.changeStable(stable);
        stable = stableDao.getStableById(usedId);
        assertNotNull(stable);
        assertEquals(newname,stable.getStablename());
        System.out.println(stable);
    }

    @Test
    void removeStable() {
        Long usedId = 3L;
        stableDao.removeStable(usedId);
        assertNull(stableDao.getStableById(usedId));
    }

    @Test
    void getStableById() {
        Long usedId = 1L;
        String exceptedname = "Moon";

        Stable stable = stableDao.getStableById(usedId);
        assertNotNull(stable);
        assertEquals(exceptedname, stable.getStablename());
        System.out.println(stable);

    }

    @Test
    void getAllStable() {
        List<Stable> stableList = stableDao.getAllStable();
        assertTrue(stableList.size()>0);
        stableList.forEach(System.out::println);
    }
}