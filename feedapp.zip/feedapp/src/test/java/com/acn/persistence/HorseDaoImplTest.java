package com.acn.persistence;

import com.acn.model.Horse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.temporal.ChronoUnit;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class HorseDaoImplTest {
    @Autowired
    HorseDao horseDao;

    @BeforeEach
    void setUp() {
        assertNotNull(horseDao);
    }

    @Test
    void saveNewHorse() {
        Horse horse = new Horse("Male","prova", "prova",3,120);
        horseDao.saveNewHorse(horse);
        assertNotNull(horse.getId());
        System.out.println(horse);
    }

    @Test
    void changeHorse() {
        Long usedId = 1L;
        String newname = "prova";
        String newnickname = "prova";
        String breed = "prova";
        Integer maxTimefed = 4;
        Integer minutesInterval= 320;

        Horse horse= horseDao.getHorseById(usedId);
        assertNotNull(horse);
        horse.setName(newname);
        horse.setNickname(newnickname);
        horse.setBreed(breed);
        horse.setMaxfeedtimes(maxTimefed);
        horse.setMinutesinterval(minutesInterval);
        horseDao.changeHorse(horse);
        horse = horseDao.getHorseById(usedId);
        assertNotNull(horse);
        assertEquals(newname, horse.getName());
        assertEquals(newnickname, horse.getNickname());
        assertEquals(breed,horse.getBreed());
        assertEquals(maxTimefed, horse.getMaxfeedtimes());
        assertEquals(minutesInterval, horse.getMinutesinterval());

        System.out.println(horse);

    }

    @Test
    void getHorseById() {
        Long usedId = 1L;
        String name = "prova";
        String nickname = "prova";
        String breed = "prova";
        Integer maxTimefed = 4;
        Integer minutesInterval= 320;

        Horse horse= horseDao.getHorseById(usedId);
        assertNotNull(horse);

        assertEquals(name, horse.getName());
        assertEquals(nickname, horse.getNickname());
        assertEquals(breed,horse.getBreed());
        assertEquals(maxTimefed, horse.getMaxfeedtimes());
        assertEquals(minutesInterval, horse.getMinutesinterval());

        System.out.println(horse);

    }

    @Test
    void getAllHorse() {

        List<Horse> horseList = horseDao.getAllHorse();
        assertTrue( horseList.size() > 0);
        horseList.forEach(System.out:: println);
    }

    @Test
    void feed() {
        Long usedId = 1L;
        Integer counter = 3;
        LocalDateTime lasttimefed = LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS);
        horseDao.feed(counter,lasttimefed, usedId);
        Horse horse= horseDao.getHorseById(usedId);
        assertNotNull(horse);
        assertEquals(counter, horse.getCountfeedtimes());
        assertEquals(lasttimefed,horse.getLasttimefed());
        System.out.println(horse);

    }

    @Test
    void changeHorseName() {
        Long usedId = 1L;
        String name = "chenge Name";
        horseDao.changeHorseName(name,usedId);
        Horse horse= horseDao.getHorseById(usedId);
        assertNotNull(horse);
        assertEquals(name, horse.getName());
        System.out.println(horse);

    }

    @Test
    void changeHorseNickname() {
        Long usedId = 1L;
        String nickname = "change Nickname";
        horseDao.changeHorseNickname(nickname,usedId);
        Horse horse= horseDao.getHorseById(usedId);
        assertNotNull(horse);
        assertEquals(nickname, horse.getNickname());
        System.out.println(horse);
    }

    @Test
    void changeHorseBreed() {
        Long usedId = 1L;
        String breed = "change breed";
        horseDao.changeHorseBreed(breed,usedId);
        Horse horse= horseDao.getHorseById(usedId);
        assertNotNull(horse);
        assertEquals(breed, horse.getBreed());
        System.out.println(horse);
    }

    @Test
    void changeHorseMaxFeedtimes() {
        Long usedId = 1L;
        Integer maxFeedTimes = 54;
        horseDao.changeHorseMaxFeedtimes(maxFeedTimes,usedId);
        Horse horse= horseDao.getHorseById(usedId);
        assertNotNull(horse);
        assertEquals(maxFeedTimes, horse.getMaxfeedtimes());
        System.out.println(horse);
    }

    @Test
    void changeHorseMinutesInterval() {
        Long usedId = 1L;
        Integer interval = 54;
        horseDao.changeHorseMinutesInterval(interval,usedId);
        Horse horse= horseDao.getHorseById(usedId);
        assertNotNull(horse);
        assertEquals(interval, horse.getMinutesinterval());
        System.out.println(horse);
    }

    @Test
    void moveToOtherStable() {
        Long stableid = 1L;
        Long horseid = 1L;
        horseDao.moveToOtherStable(stableid,horseid);
        assertNotNull(horseDao.getHorseById(horseid));
    }

    @Test
    void changeOwner() {
        Long ownerid = 1l;
        Long horseid=1l;
        horseDao.changeOwner(ownerid,horseid);
        assertNotNull(horseDao.getHorseById(horseid));
    }

    @Test
    void removeHorse() {
        Long usedId = 4L;
        horseDao.removeHorse(usedId);
        assertNull(horseDao.getHorseById(usedId));
    }
}